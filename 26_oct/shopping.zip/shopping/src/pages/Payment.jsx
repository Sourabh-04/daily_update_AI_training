function Payment({ cart }) {
  const total = cart.reduce(
    (sum, item) => sum + item.price,
    0
  );

  return (
    <div>
      <h1>Payment Page</h1>

      <h3>Total Amount: ₹{total}</h3>

      <button>
        Pay Now
      </button>
    </div>
  );
}

export default Payment;