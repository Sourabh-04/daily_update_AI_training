import { useNavigate } from "react-router-dom";

function Cart({ cart, isLoggedIn }) {
  const navigate = useNavigate();

  const total = cart.reduce(
    (sum, item) => sum + item.price,
    0
  );

  const handlePayment = () => {
    if (isLoggedIn) {
      navigate("/payment");
    } else {
      navigate("/login");
    }
  };

  return (
    <div>
      <h1>Cart</h1>

      {cart.map((item, index) => (
        <p key={index}>
          {item.name} - ₹{item.price}
        </p>
      ))}

      <h3>Total: ₹{total}</h3>

      <button onClick={handlePayment}>
        Proceed To Payment
      </button>
    </div>
  );
}

export default Cart;